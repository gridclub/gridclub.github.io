# r-summer-workshops-2016

Resources from the R Data Science Workshop series put on by GRiD, GWIS, and Western Mass Statistics and Data Science.
