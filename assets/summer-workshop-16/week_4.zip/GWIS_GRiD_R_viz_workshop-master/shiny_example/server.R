library(shiny)
library(ggplot2)

eco <- economics # from ggplot2
eco$year <- year(eco$date)
eco$month <- month(eco$date)
eco$unemploy_pct <- round((eco$unemploy / eco$pop)*100, 2)

shinyServer(function(input, output) {
  get_data <- reactive({
    eco %>% filter(year==input$year)
  })
  
  output$economics_plot <- renderPlot({
    data <- get_data()
    year <- seq(min(eco$year), max(eco$year), length.out = input$year)
    ggplot(data, aes(pce, unemploy_pct, size=uempmed)) +
      geom_point() + 
      xlab('Personal Consumption Expenditures (Billions $)') + 
      ylab('Unemployment Percent') +
      ggtitle('GGPlot Economics') + 
      theme_bw()
  })
  output$economics_plot_full <- renderPlot({
    ggplot(eco, aes(pce, unemploy_pct)) +
      geom_point(aes(size=uempmed, colour=year)) + 
      xlab('Personal Consumption Expenditures (Billions $)') + 
      ylab('Unemployment Percent') +
      ggtitle('GGPlot Economics') + 
      theme_bw()
  })
})