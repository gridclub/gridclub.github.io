library(shiny)

shinyUI(fluidPage(
  
  titlePanel('Shiny Example'),
  sidebarLayout(
    sidebarPanel(
      sliderInput('year',
                  'Year:',
                  min = 1967,
                  max = 2015,
                  value = 1967, 
                  animate = TRUE, 
                  sep='')
    ),
  mainPanel(
    plotOutput('economics_plot'), 
    plotOutput('economics_plot_full')
  )
  )
))